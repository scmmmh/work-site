var Presentation =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./scripts/presentation/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/bespoke-classes/lib/bespoke-classes.js":
/*!*************************************************************!*\
  !*** ./node_modules/bespoke-classes/lib/bespoke-classes.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function() {\n  return function(deck) {\n    var addClass = function(el, cls) {\n        el.classList.add('bespoke-' + cls);\n      },\n\n      removeClass = function(el, cls) {\n        el.className = el.className\n          .replace(new RegExp('bespoke-' + cls +'(\\\\s|$)', 'g'), ' ')\n          .trim();\n      },\n\n      deactivate = function(el, index) {\n        var activeSlide = deck.slides[deck.slide()],\n          offset = index - deck.slide(),\n          offsetClass = offset > 0 ? 'after' : 'before';\n\n        ['before(-\\\\d+)?', 'after(-\\\\d+)?', 'active', 'inactive'].map(removeClass.bind(null, el));\n\n        if (el !== activeSlide) {\n          ['inactive', offsetClass, offsetClass + '-' + Math.abs(offset)].map(addClass.bind(null, el));\n        }\n      };\n\n    addClass(deck.parent, 'parent');\n    deck.slides.map(function(el) { addClass(el, 'slide'); });\n\n    deck.on('activate', function(e) {\n      deck.slides.map(deactivate);\n      addClass(e.slide, 'active');\n      removeClass(e.slide, 'inactive');\n    });\n  };\n};\n\n\n//# sourceURL=webpack://Presentation/./node_modules/bespoke-classes/lib/bespoke-classes.js?");

/***/ }),

/***/ "./node_modules/bespoke-hash/lib/bespoke-hash.js":
/*!*******************************************************!*\
  !*** ./node_modules/bespoke-hash/lib/bespoke-hash.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function() {\n  return function(deck) {\n    var activateSlide = function(index) {\n      var indexToActivate = -1 < index && index < deck.slides.length ? index : 0;\n      if (indexToActivate !== deck.slide()) {\n        deck.slide(indexToActivate);\n      }\n    };\n\n    var parseHash = function() {\n      var hash = window.location.hash.slice(1),\n        slideNumberOrName = parseInt(hash, 10);\n\n      if (hash) {\n        if (slideNumberOrName) {\n          activateSlide(slideNumberOrName - 1);\n        } else {\n          deck.slides.forEach(function(slide, i) {\n            if (slide.getAttribute('data-bespoke-hash') === hash || slide.id === hash) {\n              activateSlide(i);\n            }\n          });\n        }\n      }\n    };\n\n    setTimeout(function() {\n      parseHash();\n\n      deck.on('activate', function(e) {\n        var slideName = e.slide.getAttribute('data-bespoke-hash') || e.slide.id;\n        window.location.hash = slideName || e.index + 1;\n      });\n\n      window.addEventListener('hashchange', parseHash);\n    }, 0);\n  };\n};\n\n\n//# sourceURL=webpack://Presentation/./node_modules/bespoke-hash/lib/bespoke-hash.js?");

/***/ }),

/***/ "./node_modules/bespoke-keys/lib/bespoke-keys.js":
/*!*******************************************************!*\
  !*** ./node_modules/bespoke-keys/lib/bespoke-keys.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function(options) {\n  return function(deck) {\n    var isHorizontal = options !== 'vertical';\n\n    document.addEventListener('keydown', function(e) {\n      if (e.which == 34 || // PAGE DOWN\n        (e.which == 32 && !e.shiftKey) || // SPACE WITHOUT SHIFT\n        (isHorizontal && e.which == 39) || // RIGHT\n        (!isHorizontal && e.which == 40) // DOWN\n      ) { deck.next(); }\n\n      if (e.which == 33 || // PAGE UP\n        (e.which == 32 && e.shiftKey) || // SPACE + SHIFT\n        (isHorizontal && e.which == 37) || // LEFT\n        (!isHorizontal && e.which == 38) // UP\n      ) { deck.prev(); }\n    });\n  };\n};\n\n\n//# sourceURL=webpack://Presentation/./node_modules/bespoke-keys/lib/bespoke-keys.js?");

/***/ }),

/***/ "./node_modules/bespoke-touch/lib/bespoke-touch.js":
/*!*********************************************************!*\
  !*** ./node_modules/bespoke-touch/lib/bespoke-touch.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function(options) {\n  return function(deck) {\n    var axis = options == 'vertical' ? 'Y' : 'X',\n      startPosition,\n      delta;\n\n    deck.parent.addEventListener('touchstart', function(e) {\n      if (e.touches.length == 1) {\n        startPosition = e.touches[0]['page' + axis];\n        delta = 0;\n      }\n    });\n\n    deck.parent.addEventListener('touchmove', function(e) {\n      if (e.touches.length == 1) {\n        e.preventDefault();\n        delta = e.touches[0]['page' + axis] - startPosition;\n      }\n    });\n\n    deck.parent.addEventListener('touchend', function() {\n      if (Math.abs(delta) > 50) {\n        deck[delta > 0 ? 'prev' : 'next']();\n      }\n    });\n  };\n};\n\n\n//# sourceURL=webpack://Presentation/./node_modules/bespoke-touch/lib/bespoke-touch.js?");

/***/ }),

/***/ "./node_modules/bespoke/lib/bespoke.js":
/*!*********************************************!*\
  !*** ./node_modules/bespoke/lib/bespoke.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var from = function(opts, plugins) {\n  var parent = (opts.parent || opts).nodeType === 1 ? (opts.parent || opts) : document.querySelector(opts.parent || opts),\n    slides = [].filter.call(typeof opts.slides === 'string' ? parent.querySelectorAll(opts.slides) : (opts.slides || parent.children), function(el) { return el.nodeName !== 'SCRIPT'; }),\n    activeSlide = slides[0],\n    listeners = {},\n\n    activate = function(index, customData) {\n      if (!slides[index]) {\n        return;\n      }\n\n      fire('deactivate', createEventData(activeSlide, customData));\n      activeSlide = slides[index];\n      fire('activate', createEventData(activeSlide, customData));\n    },\n\n    slide = function(index, customData) {\n      if (arguments.length) {\n        fire('slide', createEventData(slides[index], customData)) && activate(index, customData);\n      } else {\n        return slides.indexOf(activeSlide);\n      }\n    },\n\n    step = function(offset, customData) {\n      var slideIndex = slides.indexOf(activeSlide) + offset;\n\n      fire(offset > 0 ? 'next' : 'prev', createEventData(activeSlide, customData)) && activate(slideIndex, customData);\n    },\n\n    on = function(eventName, callback) {\n      (listeners[eventName] || (listeners[eventName] = [])).push(callback);\n      return off.bind(null, eventName, callback);\n    },\n\n    off = function(eventName, callback) {\n      listeners[eventName] = (listeners[eventName] || []).filter(function(listener) { return listener !== callback; });\n    },\n\n    fire = function(eventName, eventData) {\n      return (listeners[eventName] || [])\n        .reduce(function(notCancelled, callback) {\n          return notCancelled && callback(eventData) !== false;\n        }, true);\n    },\n\n    createEventData = function(el, eventData) {\n      eventData = eventData || {};\n      eventData.index = slides.indexOf(el);\n      eventData.slide = el;\n      return eventData;\n    },\n\n    deck = {\n      on: on,\n      off: off,\n      fire: fire,\n      slide: slide,\n      next: step.bind(null, 1),\n      prev: step.bind(null, -1),\n      parent: parent,\n      slides: slides\n    };\n\n  (plugins || []).forEach(function(plugin) {\n    plugin(deck);\n  });\n\n  activate(0);\n\n  return deck;\n};\n\nmodule.exports = {\n  from: from\n};\n\n\n//# sourceURL=webpack://Presentation/./node_modules/bespoke/lib/bespoke.js?");

/***/ }),

/***/ "./scripts/presentation/fragment.ts":
/*!******************************************!*\
  !*** ./scripts/presentation/fragment.ts ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/**\n * Fragment sorting comparison\n */\nfunction fragmentComparison(a, b) {\n  var aIndex = a.getAttribute('data-fragment-index');\n  var bIndex = b.getAttribute('data-fragment-index');\n\n  if (aIndex !== null && bIndex !== null) {\n    return Number.parseInt(aIndex) - Number.parseInt(bIndex);\n  } else if (aIndex != null) {\n    return -1;\n  } else if (bIndex != null) {\n    return 1;\n  } else {\n    return 0;\n  }\n}\n/**\n * Initialise the fragment based on its action\n */\n\n\nfunction init(fragment) {\n  fragment.classList.add('invisible');\n}\n/**\n * Cluster transitions that have the same data-fragment-index so that they happen together\n */\n\n\nfunction cluster(fragments) {\n  var clustered = [];\n  fragments.forEach(function (fragment) {\n    var index = fragment.getAttribute('data-fragment-index');\n\n    if (index) {\n      if (clustered.length > 0) {\n        if (Array.isArray(clustered[clustered.length - 1])) {\n          if (clustered[clustered.length - 1][clustered[clustered.length - 1].length - 1].getAttribute('data-fragment-index') === index) {\n            clustered[clustered.length - 1].push(fragment);\n          } else {\n            clustered.push(fragment);\n          }\n        } else {\n          if (clustered[clustered.length - 1].getAttribute('data-fragment-index') === index) {\n            clustered[clustered.length - 1] = [clustered[clustered.length - 1], fragment];\n          } else {\n            clustered.push(fragment);\n          }\n        }\n      } else {\n        clustered.push(fragment);\n      }\n    } else {\n      clustered.push(fragment);\n    }\n  });\n  return clustered;\n}\n/**\n * Apply a transition\n */\n\n\nfunction transition(fragment, reverse) {\n  if (Array.isArray(fragment)) {\n    fragment.forEach(function (part) {\n      transition(part, reverse);\n    });\n  } else {\n    if (reverse) {\n      fragment.classList.add('invisible');\n    } else {\n      fragment.classList.remove('invisible');\n    }\n  }\n}\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (function () {\n  var fragments = [];\n  var currentFragment = 0;\n  var forward = true;\n  return function (deck) {\n    deck.fragment = function (index) {\n      for (var idx = 0; idx <= index && idx < fragments.length; idx++) {\n        transition(fragments[idx]);\n      }\n    };\n\n    deck.on('activate', function (ev) {\n      currentFragment = 0;\n      fragments = [];\n      ev.slide.querySelectorAll('.fragment').forEach(function (fragment) {\n        fragments.push(fragment);\n        init(fragment);\n      });\n      fragments.sort(fragmentComparison);\n      fragments = cluster(fragments);\n\n      if (!forward) {\n        // If moving backwards, autoplay all transitions\n        fragments.forEach(function (fragment) {\n          transition(fragment);\n        });\n        currentFragment = fragments.length;\n        deck.fire('fragment-activate', {\n          slide: deck.slides[deck.slide()],\n          index: deck.slide(),\n          fragments: fragments,\n          fragment: fragments[currentFragment - 1],\n          'fragment-index': currentFragment - 1\n        });\n      }\n    });\n    deck.on('next', function (ev) {\n      forward = true;\n      currentFragment = Math.min(fragments.length + 1, currentFragment + 1);\n\n      if (currentFragment <= fragments.length) {\n        transition(fragments[currentFragment - 1]);\n        deck.fire('fragment-activate', {\n          slide: deck.slides[deck.slide()],\n          index: deck.slide(),\n          fragments: fragments,\n          fragment: fragments[currentFragment - 1],\n          'fragment-index': currentFragment - 1\n        });\n        return false;\n      } else {\n        currentFragment = fragments.length;\n        return true;\n      }\n    });\n    deck.on('prev', function (ev) {\n      forward = false;\n      currentFragment = Math.max(-1, currentFragment - 1);\n\n      if (currentFragment >= 0 && currentFragment <= fragments.length) {\n        transition(fragments[currentFragment], true);\n        deck.fire('fragment-activate', {\n          slide: deck.slides[deck.slide()],\n          index: deck.slide(),\n          fragments: fragments,\n          fragment: fragments[currentFragment - 1],\n          'fragment-index': currentFragment - 1\n        });\n        return false;\n      } else {\n        currentFragment = 0;\n        return true;\n      }\n    });\n  };\n});\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/fragment.ts?");

/***/ }),

/***/ "./scripts/presentation/index.ts":
/*!***************************************!*\
  !*** ./scripts/presentation/index.ts ***!
  \***************************************/
/*! exports provided: install */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"install\", function() { return install; });\n/* harmony import */ var bespoke__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bespoke */ \"./node_modules/bespoke/lib/bespoke.js\");\n/* harmony import */ var bespoke__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bespoke__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bespoke_classes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bespoke-classes */ \"./node_modules/bespoke-classes/lib/bespoke-classes.js\");\n/* harmony import */ var bespoke_classes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bespoke_classes__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var bespoke_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bespoke-keys */ \"./node_modules/bespoke-keys/lib/bespoke-keys.js\");\n/* harmony import */ var bespoke_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bespoke_keys__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var bespoke_touch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bespoke-touch */ \"./node_modules/bespoke-touch/lib/bespoke-touch.js\");\n/* harmony import */ var bespoke_touch__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bespoke_touch__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var bespoke_hash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bespoke-hash */ \"./node_modules/bespoke-hash/lib/bespoke-hash.js\");\n/* harmony import */ var bespoke_hash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bespoke_hash__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _notes_ts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./notes.ts */ \"./scripts/presentation/notes.ts\");\n/* harmony import */ var _menu_ts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./menu.ts */ \"./scripts/presentation/menu.ts\");\n/* harmony import */ var _progress_ts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./progress.ts */ \"./scripts/presentation/progress.ts\");\n/* harmony import */ var _fragment_ts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./fragment.ts */ \"./scripts/presentation/fragment.ts\");\n/* harmony import */ var _presenter_ts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./presenter.ts */ \"./scripts/presentation/presenter.ts\");\n\n\n\n\n\n\n\n\n\n\n\nfunction resize(anchorPoint) {\n  return function () {\n    var slideContainer = document.querySelector(anchorPoint);\n    var parent = slideContainer.parentElement;\n    var xScale = (parent.clientWidth - 20) / 1024;\n    var yScale = (parent.clientHeight - 20) / 576;\n    slideContainer.style.transform = 'scale(' + Math.min(xScale, yScale) + ')';\n  };\n}\n\nfunction install(anchorPoint, notePoint, menuPoint, progressPoint, presenterToggle, presenterPoint) {\n  if (window.location.search.indexOf('presentation-mode=presenter') >= 0) {\n    document.querySelector(presenterPoint).classList.add('is-active'); // Move presentation in presenter main view\n\n    var anchor = document.querySelector(anchorPoint);\n    document.querySelector(presenterPoint + ' .current-view').appendChild(anchor.parentElement);\n    anchor.querySelector('* > nav').remove();\n    var preview = anchor.parentElement.cloneNode(true);\n    document.querySelector(presenterPoint + ' .pre-view').appendChild(preview);\n    preview.querySelector('.slide-container').appendChild(document.createElement('section')); // Add resizers\n\n    var resizer = resize(anchorPoint);\n    resizer();\n    window.addEventListener('resize', resizer);\n    resizer = resize(presenterPoint + ' .pre-view .slide-container');\n    resizer();\n    window.addEventListener('resize', resizer);\n    window.mainDeck = bespoke__WEBPACK_IMPORTED_MODULE_0___default.a.from({\n      parent: anchorPoint,\n      slides: 'section'\n    }, [bespoke_classes__WEBPACK_IMPORTED_MODULE_1___default()(), Object(_progress_ts__WEBPACK_IMPORTED_MODULE_7__[\"default\"])(progressPoint), Object(_fragment_ts__WEBPACK_IMPORTED_MODULE_8__[\"default\"])()]);\n    window.previewDeck = bespoke__WEBPACK_IMPORTED_MODULE_0___default.a.from({\n      parent: presenterPoint + ' .pre-view .slide-container',\n      slides: 'section'\n    }, [bespoke_classes__WEBPACK_IMPORTED_MODULE_1___default()(), Object(_fragment_ts__WEBPACK_IMPORTED_MODULE_8__[\"default\"])()]);\n  } else {\n    var _anchor = document.querySelector(anchorPoint);\n\n    var _resizer = resize(anchorPoint);\n\n    _resizer();\n\n    window.addEventListener('resize', _resizer);\n\n    _anchor.querySelector('.presentation-menu a[data-action=\"toggle-fullscreen\"]').addEventListener('click', function (ev) {\n      _anchor.parentElement.classList.toggle('fullscreen');\n\n      if (_anchor.parentElement.classList.contains('fullscreen')) {\n        ev.target.parentElement.setAttribute('aria-current', 'true');\n      } else {\n        ev.target.parentElement.setAttribute('aria-current', 'false');\n      }\n\n      _resizer();\n    });\n\n    bespoke__WEBPACK_IMPORTED_MODULE_0___default.a.from({\n      parent: anchorPoint,\n      slides: 'section'\n    }, [bespoke_classes__WEBPACK_IMPORTED_MODULE_1___default()(), bespoke_keys__WEBPACK_IMPORTED_MODULE_2___default()(), bespoke_touch__WEBPACK_IMPORTED_MODULE_3___default()(), bespoke_hash__WEBPACK_IMPORTED_MODULE_4___default()(), Object(_notes_ts__WEBPACK_IMPORTED_MODULE_5__[\"default\"])(notePoint), Object(_menu_ts__WEBPACK_IMPORTED_MODULE_6__[\"default\"])(menuPoint), Object(_progress_ts__WEBPACK_IMPORTED_MODULE_7__[\"default\"])(progressPoint), Object(_fragment_ts__WEBPACK_IMPORTED_MODULE_8__[\"default\"])(), Object(_presenter_ts__WEBPACK_IMPORTED_MODULE_9__[\"default\"])(presenterToggle)]);\n  }\n}\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/index.ts?");

/***/ }),

/***/ "./scripts/presentation/menu.ts":
/*!**************************************!*\
  !*** ./scripts/presentation/menu.ts ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (function (menuPoint) {\n  return function (deck) {\n    var menu = document.querySelector(menuPoint); // Make the current page menu an ancestor\n\n    var pageMenu = menu.querySelector('li:last-child a');\n    pageMenu.classList.add('ancestor');\n    pageMenu.classList.add('bottom-separator');\n    pageMenu.removeAttribute('aria-current'); // Source the menu from the slides with ids\n\n    deck.slides.forEach(function (slide, idx) {\n      if (slide.getAttribute('id')) {\n        if (slide.querySelector('h1 a') !== null) {\n          // If the title already contains a link, use that\n          var item = document.createElement('li');\n          item.innerHTML = slide.querySelector('h1').innerHTML;\n          var link = item.querySelector('a');\n          link.setAttribute('role', 'menuitem');\n          link.setAttribute('tabindex', '-1');\n          link.setAttribute('data-for', slide.getAttribute('id'));\n          menu.appendChild(item);\n        } else {\n          // Title can come from the data-menu-label attribute or from the h1\n          var title = 'Slide ' + (idx + 1);\n\n          if (slide.getAttribute('data-menu-label')) {\n            title = slide.getAttribute('data-menu-label');\n          } else {\n            title = slide.querySelector('h1');\n\n            if (title) {\n              title = title.innerHTML;\n            }\n          }\n\n          if (title) {\n            var _item = document.createElement('li');\n\n            var _link = document.createElement('a');\n\n            _link.setAttribute('role', 'menuitem');\n\n            _link.setAttribute('tabindex', '-1');\n\n            _link.setAttribute('href', '#' + slide.getAttribute('id'));\n\n            _link.setAttribute('data-for', slide.getAttribute('id'));\n\n            _link.innerHTML = title;\n\n            _item.appendChild(_link);\n\n            menu.appendChild(_item);\n          }\n        }\n      }\n    }); // Update the active menu when the slide changes\n\n    deck.on('activate', function (ev) {\n      var start = ev.index;\n\n      for (var idx = start; idx >= 0; idx--) {\n        if (deck.slides[idx].getAttribute('id')) {\n          var current = menu.querySelector('a[data-for=\"' + deck.slides[idx].getAttribute('id') + '\"]');\n\n          if (current) {\n            menu.querySelectorAll('a[aria-current=\"true\"]').forEach(function (item) {\n              item.setAttribute('aria-current', 'false');\n            });\n            current.setAttribute('aria-current', 'true');\n          }\n\n          break;\n        }\n      }\n    });\n  };\n});\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/menu.ts?");

/***/ }),

/***/ "./scripts/presentation/notes.ts":
/*!***************************************!*\
  !*** ./scripts/presentation/notes.ts ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nfunction setNotes(slide, notePoint) {\n  var notes = slide.querySelector('.notes');\n\n  if (notes) {\n    document.querySelector(notePoint).innerHTML = notes.innerHTML;\n  } else {\n    document.querySelector(notePoint).innerHTML = '';\n  }\n}\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (function (notePoint) {\n  return function (deck) {\n    if (document.querySelector(notePoint)) {\n      deck.on('activate', function (ev) {\n        setNotes(ev.slide, notePoint);\n      });\n    }\n  };\n});\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/notes.ts?");

/***/ }),

/***/ "./scripts/presentation/presenter.ts":
/*!*******************************************!*\
  !*** ./scripts/presentation/presenter.ts ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (function (launchPoint) {\n  var presenter = null;\n  return function (deck) {\n    document.querySelector(launchPoint).addEventListener('click', function (ev) {\n      ev.preventDefault();\n      presenter = window.open('?presentation-mode=presenter', 'presenter', 'menubar=no,location=no,resizable=yes,status=yes,width=1024,height=584');\n      presenter.addEventListener('load', function () {\n        presenter.document.body.addEventListener('keydown', function (ev) {\n          if (ev.keyCode === 39 || ev.keyCode === 40 || ev.keyCode === 32) {\n            deck.next();\n          } else if (ev.keyCode === 37 || ev.keyCode === 40) {\n            deck.prev();\n          }\n        });\n\n        if (presenter.mainDeck) {\n          presenter.mainDeck.slide(deck.slide());\n        }\n\n        if (presenter.previewDeck) {\n          presenter.previewDeck.slide(deck.slide());\n          presenter.previewDeck.next();\n        }\n      });\n    });\n    deck.on('activate', function (ev) {\n      if (presenter && presenter.mainDeck && presenter.mainDeck.slide() !== ev.index) {\n        presenter.mainDeck.slide(ev.index);\n        presenter.previewDeck.slide(ev.index);\n        presenter.previewDeck.next();\n      }\n\n      if (presenter) {\n        if (ev.slide.querySelector('.notes')) {\n          presenter.document.querySelector('#presenter-notes').innerHTML = ev.slide.querySelector('.notes').innerHTML;\n        } else {\n          presenter.document.querySelector('#presenter-notes').innerHTML = '';\n        }\n      }\n    });\n    deck.on('fragment-activate', function (ev) {\n      if (presenter && presenter.mainDeck) {\n        presenter.mainDeck.slide(ev.index);\n        presenter.mainDeck.fragment(ev['fragment-index']);\n        presenter.previewDeck.slide(ev.index);\n        presenter.previewDeck.fragment(ev['fragment-index']);\n\n        for (var idx = 0; idx <= ev['fragment-index'] + 1; idx++) {\n          presenter.previewDeck.next();\n        }\n      }\n    });\n  };\n});\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/presenter.ts?");

/***/ }),

/***/ "./scripts/presentation/progress.ts":
/*!******************************************!*\
  !*** ./scripts/presentation/progress.ts ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (function (progressPoint) {\n  return function (deck) {\n    var progressBar = document.querySelector(progressPoint);\n    var meter = progressBar.children[0];\n    deck.on('activate', function (ev) {\n      var idx = ev.index == 0 ? 0 : ev.index + 1;\n      meter.style.width = idx / deck.slides.length * 100 + '%';\n    });\n    deck.on('fragment-activate', function (ev) {\n      var idx = ev.index === 0 ? 0 : ev.index + 1;\n      idx = idx + (ev['fragment-index'] + 1) / (ev.fragments.length + 1);\n      meter.style.width = idx / deck.slides.length * 100 + '%';\n    });\n  };\n});\n\n//# sourceURL=webpack://Presentation/./scripts/presentation/progress.ts?");

/***/ })

/******/ });